from django.shortcuts import redirect,render

def index (request):
    
  return render(request,'index.html')
def about (request):
    
  return render(request,'about.html')

def service (request):
    
  return render(request,'service-details.html')

def blog (request):
    
  return render(request,'blog.html')

def blogdetails(request):
    
  return render(request,'blog-details.html')

def portfolio (request):
    
  return render(request,'portfolio-details.html')

def contact (request):
    
  return render(request,'contact.html')
def team (request):
    return render(request,'team.html')
