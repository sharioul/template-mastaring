from django.contrib import admin
from django.urls import path
from testproject.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index,name='index'),
    path('about',about,name='about'),
    path('service',service,name='service'),
    path('blog',blog,name='blog'),
    path('blogdetails',blogdetails,name='blogdetails'),
    path('portfolio',portfolio,name='portfolio'),
    path('contact',contact,name='contact'),
    path('team',team,name='team'),
]

